from superwires import games
import math,os,socket

MOVING_FRICTION=.2	
SLOWING_FRICTION=.05
ACCEL=3
ROT_SPEED=5
MISSILE_DELAY=50
MISSILE_VELOCITY=15
MISSILE_LIFE=150
MISSILE_BUFFER=10
MISSILE_IMAGE=None

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

def full_recv(conn, step=1):
	message=""
	while not message.endswith("|"):
		message+=conn.recv(step)
	
	return message.replace("|", "")

class Wrapper(games.Sprite):
	def check_wrap(self):
		if self.left>games.screen.width: self.left=0
		if self.right<0: self.right=games.screen.width
		if self.top>games.screen.height: self.top=0
		if self.bottom<0: self.bottom=games.screen.height

class Ship(Wrapper):
	
	KEYS=[games.K_RIGHT, games.K_LEFT, games.K_UP, games.K_SPACE]
	
	def __init__(self, num):
		games.Sprite.__init__(self, games.load_image(resource_path('res/ship'+str(num)+'.png')), x=games.screen.width/2, y=games.screen.height/2)
		self.convert=lambda t,r:(-math.cos(math.pi*t/180)*r, -math.sin(math.pi*t/180)*r)
		self.v=self.a=0
		self.keys=[]
	
	def add_missile(self):
		global MISSILE_IMAGE
		if not MISSILE_IMAGE: MISSILE_IMAGE=games.load_image(resource_path('res/missile.png'), transparent=False)
		buffer=self.convert(self.angle, (MISSILE_BUFFER+self.width/2))
		games.screen.add(Missile(buffer[0]+self.x, buffer[1]+self.y, *self.convert(self.angle, MISSILE_VELOCITY)))
	
	def update(self):
		#Physics
		self.a-=(MOVING_FRICTION if self.a else SLOWING_FRICTION)*self.v
		self.v=max(0, self.a+self.v)
		
		#Controls
		if games.K_RIGHT in self.keys: self.angle+=ROT_SPEED
		if games.K_LEFT in self.keys: self.angle-=ROT_SPEED
		self.a=ACCEL if games.K_UP in self.keys else 0
		
		#Compute component velocity vectors in Cartesian form
		self.dx,self.dy=self.convert(self.angle, self.v)

		#Check Wrapping
		self.check_wrap()
	
	def tick(self):
		self.interval=1
		if games.K_SPACE in self.keys:
			self.interval=MISSILE_DELAY
			self.add_missile()

class Missile(Wrapper):
	def __init__(self, x, y, dx, dy):
		games.Sprite.__init__(self, MISSILE_IMAGE, x=x, y=y, dx=dx, dy=dy, interval=MISSILE_LIFE)
		self.tick=self.destroy

	def update(self):
		self.check_wrap()